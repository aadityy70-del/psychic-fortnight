package dev.lelonio.square.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import com.adamglin.phosphoricons.PhosphorIcons
import com.adamglin.phosphoricons.fill.Heart
import com.adamglin.phosphoricons.regular.SpeakerHifi
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import dev.lelonio.square.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Saving a song: its cover rises from the middle of the screen, shrinks and
 * sinks toward the bar, and a ring spreads out over the page from there.
 */
object KeepFx {
    val url = mutableStateOf<String?>(null)
    val stamp = mutableLongStateOf(0L)

    /** A heart popping up in the middle of the screen; the stamp of when. */
    val heart = mutableLongStateOf(0L)

    fun fire(artworkUrl: String?) {
        if (artworkUrl.isNullOrBlank()) return
        url.value = artworkUrl
        stamp.longValue = SystemClock.uptimeMillis()
    }
}

@Composable
fun KeepOverlay() {
    val artwork = KeepFx.url.value ?: return
    val stamp = KeepFx.stamp.longValue
    val progress = remember(stamp) { Animatable(0f) }
    LaunchedEffect(stamp) {
        progress.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
        KeepFx.url.value = null
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height - 90.dp.toPx())
            val p = progress.value
            drawCircle(
                color = Color.White.copy(alpha = (1f - p) * 0.30f),
                radius = p * size.height * 1.15f,
                center = center,
                style = Stroke(3.dp.toPx()),
            )
            val q = ((p - 0.18f) / 0.82f).coerceIn(0f, 1f)
            drawCircle(
                color = Color.White.copy(alpha = (1f - q) * 0.18f),
                radius = q * size.height * 1.15f,
                center = center,
                style = Stroke(2.dp.toPx()),
            )
        }
        AsyncImage(
            model = artwork,
            contentDescription = null,
            modifier = Modifier
                .size(220.dp)
                .graphicsLayer {
                    val t = progress.value
                    // Held a moment, then falling toward the bar.
                    val fall = ((t - 0.15f) / 0.85f).coerceIn(0f, 1f)
                    val eased = fall * fall
                    translationY = eased * 900.dp.toPx()
                    val scale = 1f - 0.85f * eased
                    scaleX = scale
                    scaleY = scale
                    alpha = 1f - eased * eased
                }
                .clip(RoundedCornerShape(22.dp)),
        )
    }
}

/**
 * A card of the playing song in black metal, story-sized, handed to the share sheet.
 *
 * Drawn straight to a bitmap, so what is shared is the same picture whatever
 * the screen was doing.
 */
suspend fun shareTrackCard(context: Context, title: String, artist: String, artworkUrl: String?) {
    val file = withContext(Dispatchers.Default) {
        runCatching { buildCard(context, title, artist, artworkUrl) }.getOrNull()
    } ?: return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.reports", file)
    val send = Intent(Intent.ACTION_SEND)
        .setType("image/png")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private suspend fun buildCard(context: Context, title: String, artist: String, artworkUrl: String?): File {
    val w = 1080
    val h = 1920
    val cover: Bitmap? = artworkUrl?.let { url ->
        val result = context.imageLoader.execute(
            ImageRequest.Builder(context).data(url).allowHardware(false).size(900).build(),
        )
        (result as? SuccessResult)?.drawable?.toBitmap(900, 900)
    }
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(bmp)

    // The plate: black steel, lighter through the middle.
    val plate = Paint(Paint.ANTI_ALIAS_FLAG)
    plate.shader = LinearGradient(
        0f, 0f, 0f, h.toFloat(),
        intArrayOf(0xFF08080A.toInt(), 0xFF1C1D22.toInt(), 0xFF0A0A0C.toInt()),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP,
    )
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), plate)

    // Brushed grain: hair-fine horizontal lines.
    val grain = Paint().apply { strokeWidth = 1f; color = 0x0DFFFFFF }
    var y = 0f
    while (y < h) {
        c.drawLine(0f, y, w.toFloat(), y, grain)
        y += 4f
    }

    // The light across it: a soft diagonal band.
    val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    sheen.shader = LinearGradient(
        0f, h * 0.15f, w.toFloat(), h * 0.55f,
        intArrayOf(0x00FFFFFF, 0x22FFFFFF, 0x00FFFFFF),
        floatArrayOf(0.2f, 0.5f, 0.8f), Shader.TileMode.CLAMP,
    )
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), sheen)

    // The cover in a silver bezel.
    val side = 780f
    val left = (w - side) / 2f
    val top = 250f
    val frame = RectF(left - 14f, top - 14f, left + side + 14f, top + side + 14f)
    val bezel = Paint(Paint.ANTI_ALIAS_FLAG)
    bezel.shader = LinearGradient(
        frame.left, frame.top, frame.right, frame.bottom,
        intArrayOf(0xFFF2F3F6.toInt(), 0xFF6D7078.toInt(), 0xFFE6E8EC.toInt(), 0xFF50535A.toInt()),
        floatArrayOf(0f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP,
    )
    c.drawRoundRect(frame, 46f, 46f, bezel)
    val clip = Path().apply { addRoundRect(RectF(left, top, left + side, top + side), 36f, 36f, Path.Direction.CW) }
    c.save()
    c.clipPath(clip)
    if (cover != null) {
        c.drawBitmap(cover, null, RectF(left, top, left + side, top + side), Paint(Paint.FILTER_BITMAP_FLAG))
    } else {
        c.drawRect(left, top, left + side, top + side, Paint().apply { color = 0xFF222226.toInt() })
    }
    c.restore()

    // The title, in silver; the artist under it, greyer.
    val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF4F5F7.toInt(); textSize = 72f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, 880)
        .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
    c.save()
    c.translate((w - 880) / 2f, top + side + 90f)
    titleLayout.draw(c)
    c.restore()
    val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9A9CA3.toInt(); textSize = 46f
    }
    val artistLayout = StaticLayout.Builder.obtain(artist, 0, artist.length, artistPaint, 880)
        .setMaxLines(1).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
    c.save()
    c.translate((w - 880) / 2f, top + side + 90f + titleLayout.height + 24f)
    artistLayout.draw(c)
    c.restore()

    // The maker's mark.
    val logo = BitmapFactory.decodeResource(context.resources, R.drawable.splash_logo)
    if (logo != null) {
        c.drawBitmap(logo, null, RectF(w / 2f - 70f, h - 330f, w / 2f + 70f, h - 190f), Paint(Paint.FILTER_BITMAP_FLAG))
    }
    val mark = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB8BAC0.toInt(); textSize = 34f; letterSpacing = 0.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.CENTER
    }
    c.drawText("TITOPLAY", w / 2f, h - 130f, mark)

    val dir = File(context.cacheDir, "cards").apply { mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    val out = File(dir, "titoplay-card.png")
    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return out
}


/**
 * A double tap, noticed without taking the touch from anyone: the taps still
 * reach whatever is under them. Two quick, still taps within about a third of a second.
 */
fun Modifier.onDoubleTapKeepingTouch(onDouble: () -> Unit): Modifier = androidx.compose.ui.input.pointer.pointerInput(Unit) {
    var lastTapUp = 0L
    androidx.compose.foundation.gestures.awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = androidx.compose.ui.input.pointer.PointerEventPass.Initial)
        var moved = false
        var upAt = 0L
        while (true) {
            val event = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
            val change = event.changes.firstOrNull() ?: break
            if ((change.position - down.position).getDistance() > viewConfiguration.touchSlop) moved = true
            if (!change.pressed) {
                upAt = change.uptimeMillis
                break
            }
        }
        if (!moved && upAt - down.uptimeMillis < 250L) {
            if (down.uptimeMillis - lastTapUp < 320L) {
                lastTapUp = 0L
                onDouble()
            } else {
                lastTapUp = upAt
            }
        }
    }
}

/** The heart that pops up over the page when a double tap likes the song. */
@Composable
fun HeartPop() {
    val stamp = KeepFx.heart.longValue
    if (stamp == 0L) return
    val t = remember(stamp) { Animatable(0f) }
    LaunchedEffect(stamp) {
        t.animateTo(1f, tween(800, easing = FastOutSlowInEasing))
        KeepFx.heart.longValue = 0L
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        androidx.compose.material3.Icon(
            com.adamglin.phosphoricons.PhosphorIcons.Fill.Heart,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier
                .size(120.dp)
                .graphicsLayer {
                    val p = t.value
                    // Springs up past full size, settles, then lifts away.
                    val grow = if (p < 0.3f) p / 0.3f * 1.25f else 1.25f - 0.25f * ((p - 0.3f) / 0.2f).coerceAtMost(1f)
                    scaleX = grow
                    scaleY = grow
                    translationY = -((p - 0.55f).coerceAtLeast(0f)) * 260.dp.toPx()
                    alpha = if (p < 0.55f) 1f else 1f - (p - 0.55f) / 0.45f
                },
        )
    }
}


/**
 * The volume, under a thumb: up or down along the right edge of the cover
 * page. A slim bar shows where it stands and fades a moment after the last move.
 */
object VolumeFx {
    val level = androidx.compose.runtime.mutableFloatStateOf(0f)
    val stamp = mutableLongStateOf(0L)
}

fun Modifier.volumeSwipe(): Modifier = androidx.compose.ui.composed {
    val context = androidx.compose.ui.platform.LocalContext.current
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.ui.input.pointer.pointerInput(Unit) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val stream = android.media.AudioManager.STREAM_MUSIC
        var level = 0f
        var step = 0
        androidx.compose.foundation.gestures.detectVerticalDragGestures(
            onDragStart = {
                val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
                step = audio.getStreamVolume(stream)
                level = step / max.toFloat()
                VolumeFx.level.floatValue = level
                VolumeFx.stamp.longValue = SystemClock.uptimeMillis()
            },
        ) { change, dy ->
            change.consume()
            val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
            // Dragging the strip's whole height is the whole range, and a little more.
            level = (level - dy / (size.height * 0.85f)).coerceIn(0f, 1f)
            val target = kotlin.math.round(level * max).toInt()
            if (target != step) {
                step = target
                runCatching { audio.setStreamVolume(stream, target, 0) }
                view.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
            }
            VolumeFx.level.floatValue = level
            VolumeFx.stamp.longValue = SystemClock.uptimeMillis()
        }
    }
}

@Composable
fun VolumeHud() {
    val stamp = VolumeFx.stamp.longValue
    if (stamp == 0L) return
    val fade = remember { Animatable(0f) }
    LaunchedEffect(stamp) {
        fade.snapTo(1f)
        kotlinx.coroutines.delay(900)
        fade.animateTo(0f, tween(350))
        if (VolumeFx.stamp.longValue == stamp) VolumeFx.stamp.longValue = 0L
    }
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 18.dp)
                .graphicsLayer { alpha = fade.value }
                .size(width = 46.dp, height = 190.dp)
                .clip(RoundedCornerShape(23.dp))
                .background(Color.Black.copy(alpha = 0.55f)),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(190.dp * VolumeFx.level.floatValue)
                    .background(Color.White.copy(alpha = 0.92f)),
            )
            androidx.compose.material3.Icon(
                PhosphorIcons.Regular.SpeakerHifi,
                contentDescription = null,
                tint = Color(0xFF111111).copy(alpha = 0.85f),
                modifier = Modifier
                    .padding(bottom = 10.dp)
                    .size(20.dp),
            )
        }
    }
}
